package edu.handong.csee.plt.val;

public class First extends Value{

	public String getValueCode() {
		return "'#&#f";
	}
	
}
