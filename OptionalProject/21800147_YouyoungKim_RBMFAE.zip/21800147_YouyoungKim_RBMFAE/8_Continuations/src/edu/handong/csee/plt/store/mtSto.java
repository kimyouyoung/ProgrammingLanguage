package edu.handong.csee.plt.store;

public class mtSto extends Store{
	
	public String getStoreCode() {
		return "(mtSto)";
	}
	
}
