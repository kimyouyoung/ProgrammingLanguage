package edu.handong.csee.plt;

import edu.handong.csee.plt.store.*;
import edu.handong.csee.plt.val.*;

public interface Lambda {

	public ValueStore useLambda(Value val1, Value val2, Store sto);
	
}
