package edu.handong.csee.plt.defsub;

public class mtSub extends DefrdSub{
	
	public String getDefrdSubCode() {
		return "(mtSub)";
	}

}
